## Ogma.js v5.2.6

### How to install

**Through npm**

If you are developing locally and your account has access the outside Internet, you can also install directly.

```bash
npm install --save https://get.linkurio.us/api/get/npm/ogma/<VERSION>/?secret=<YOUR_API_KEY>
# or with yarn
yarn add https://get.linkurio.us/api/get/npm/ogma/<VERSION>.tgz?secret=<YOUR_API_KEY>
```

If you cannot use `npm` from external sources, because of company policy, you can always install it via `tar.gz`.

**Using downloaded `tar.gz`**

The same link used for the `npm` version can be used to download a `tar.gz` file: just past it into your browser to download the file.
Once downloaded it is possible to tell `npm` to use it to install locally:

```sh
npm install --save path/to/ogma-v.X.X.X.tar.gz
```

**Using downloaded `zip` (no bundler)**

Download Ogma as **ogma.zip** archive from [get.linkurio.us](https://get.linkurio.us) and extract it in your project folder.
In your HTML page point to the `ogma.js` file.

```html
<script src="path/to/ogma.js"></script>
<script>
  const ogma = new Ogma();
  ...
</script>
```

Or, with ES modules:

```html
<script src="path/to/ogma.mjs" type="module"></script>
<script>
  import { Ogma } from '/modules/ogma.mjs';
  const ogma = new Ogma();
  ...
</script>
```

Make sure the path is reachable from your web server.
